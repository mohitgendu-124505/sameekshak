import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPolicySchema, insertVoteSchema, insertCommentSchema } from "@shared/schema";
import { z } from "zod";
import axios from "axios";
import { marked } from "marked";
import createDOMPurify from "dompurify";
import { JSDOM } from "jsdom";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all policies
  app.get("/api/policies", async (req, res) => {
    try {
      const policies = await storage.getPolicies();
      res.json(policies);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch policies" });
    }
  });

  // Get single policy
  app.get("/api/policies/:id", async (req, res) => {
    try {
      const policy = await storage.getPolicy(req.params.id);
      if (!policy) {
        return res.status(404).json({ message: "Policy not found" });
      }
      res.json(policy);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch policy" });
    }
  });

  // Create new policy
  app.post("/api/policies", async (req, res) => {
    try {
      const validatedData = insertPolicySchema.parse(req.body);
      const policy = await storage.createPolicy(validatedData);
      res.status(201).json(policy);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid policy data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create policy" });
    }
  });

  // Update policy
  app.put("/api/policies/:id", async (req, res) => {
    try {
      const updates = req.body;
      const policy = await storage.updatePolicy(req.params.id, updates);
      if (!policy) {
        return res.status(404).json({ message: "Policy not found" });
      }
      res.json(policy);
    } catch (error) {
      res.status(500).json({ message: "Failed to update policy" });
    }
  });

  // Delete policy
  app.delete("/api/policies/:id", async (req, res) => {
    try {
      const deleted = await storage.deletePolicy(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Policy not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete policy" });
    }
  });

  // Get votes for a policy
  app.get("/api/policies/:id/votes", async (req, res) => {
    try {
      const votes = await storage.getVotesByPolicy(req.params.id);
      res.json(votes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch votes" });
    }
  });

  // Get vote statistics for a policy
  app.get("/api/policies/:id/stats", async (req, res) => {
    try {
      const stats = await storage.getVoteStats(req.params.id);
      const total = Object.values(stats).reduce((sum, count) => sum + count, 0);
      
      const result = {
        stats,
        total,
        percentages: Object.fromEntries(
          Object.entries(stats).map(([type, count]) => [
            type, 
            total > 0 ? Math.round((count / total) * 100) : 0
          ])
        )
      };
      
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch vote statistics" });
    }
  });

  // Submit a vote
  app.post("/api/votes", async (req, res) => {
    try {
      const validatedData = insertVoteSchema.parse(req.body);
      const vote = await storage.createVote(validatedData);
      
      // Emit real-time update to all clients watching this policy
      const io = (app as any).io;
      if (io) {
        const updatedStats = await storage.getVoteStats(validatedData.policyId);
        io.to(`policy-${validatedData.policyId}`).emit("vote-update", {
          vote: vote,
          stats: updatedStats
        });
        io.emit("notification", {
          type: "vote",
          message: `New ${validatedData.voteType} vote received`,
          timestamp: new Date().toISOString()
        });
      }
      
      res.status(201).json(vote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid vote data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit vote" });
    }
  });

  // Get current active policy
  app.get("/api/current-policy", async (req, res) => {
    try {
      const policies = await storage.getPolicies();
      const activePolicy = policies.find(p => p.status === "active");
      if (!activePolicy) {
        return res.status(404).json({ message: "No active policy found" });
      }
      res.json(activePolicy);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch current policy" });
    }
  });

  // Get comments for a policy
  app.get("/api/policies/:id/comments", async (req, res) => {
    try {
      const comments = await storage.getCommentsByPolicy(req.params.id);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // Submit a comment
  app.post("/api/comments", async (req, res) => {
    try {
      const validatedData = insertCommentSchema.parse(req.body);
      const comment = await storage.createComment(validatedData);
      
      // Emit real-time update to all clients watching this policy
      const io = (app as any).io;
      if (io) {
        io.to(`policy-${validatedData.policyId}`).emit("comment-update", {
          comment: comment
        });
        io.emit("notification", {
          type: "comment",
          message: `New comment: "${validatedData.content.slice(0, 50)}${validatedData.content.length > 50 ? '...' : ''}"`,
          timestamp: new Date().toISOString()
        });
      }
      
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit comment" });
    }
  });

  // Get all comments for AI summary
  app.get("/api/comments", async (req, res) => {
    try {
      const comments = await storage.getComments();
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // Get geographical sentiment data for emotion map
  app.get("/api/geographical-data", async (req, res) => {
    try {
      const geographicalData = await storage.getGeographicalData();
      res.json(geographicalData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch geographical data" });
    }
  });

  // Generate AI insights using Gemini AI
  app.post("/api/ai/insights", async (req, res) => {
    try {
      const { policyId } = req.body;
      
      // Get ALL comments for comprehensive analysis instead of just one policy
      const allComments = await storage.getComments();
      const policies = await storage.getPolicies();
      const activePolicy = policies.find(p => p.id === policyId) || policies.find(p => p.status === "active");
      
      if (!activePolicy) {
        return res.status(404).json({ message: "No active policy found" });
      }

      // Get comprehensive statistics from all comments
      const sentimentBreakdown = allComments.reduce((acc, comment) => {
        const sentiment = comment.sentiment || 'neutral';
        acc[sentiment] = (acc[sentiment] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      // Group comments by geographical region for geographical insights
      const geographicalBreakdown = allComments.reduce((acc, comment) => {
        if (comment.state) {
          const key = comment.state;
          if (!acc[key]) acc[key] = { positive: 0, negative: 0, neutral: 0, suggestion: 0, total: 0 };
          acc[key][comment.sentiment as keyof typeof acc[string]]++;
          acc[key].total++;
        }
        return acc;
      }, {} as Record<string, Record<string, number>>);

      // Create chunks of comments for better AI processing (max 100 comments per chunk)
      const chunkSize = 100;
      const commentChunks = [];
      for (let i = 0; i < allComments.length; i += chunkSize) {
        commentChunks.push(allComments.slice(i, i + chunkSize));
      }

      // Prepare comprehensive data for AI analysis
      const totalComments = allComments.length;
      const recentComments = allComments.slice(0, 200); // Analyze most recent 200 comments in detail
      const commentsText = recentComments.map((c, idx) => `${idx + 1}. "${c.content}" (${c.sentiment}, ${c.state || 'Unknown'} - ${c.city || 'Unknown'})`).join('\n');
      
      const query = `As an expert policy analyst for e.Sameekshak (Government Policy Feedback Platform), analyze this comprehensive citizen feedback data:

**DATASET OVERVIEW:**
- Total Comments Analyzed: ${totalComments}
- Sentiment Distribution: ${JSON.stringify(sentimentBreakdown)}
- Geographic Coverage: ${Object.keys(geographicalBreakdown).length} states across India
- Analysis Focus: ${activePolicy.title}

**DETAILED FEEDBACK (Sample of ${recentComments.length} most recent comments):**
${commentsText}

**GEOGRAPHICAL SENTIMENT BREAKDOWN:**
${Object.entries(geographicalBreakdown).slice(0, 10).map(([state, data]) => 
  `${state}: ${data.total} comments (Positive: ${data.positive}, Negative: ${data.negative}, Neutral: ${data.neutral}, Suggestions: ${data.suggestion || 0})`
).join('\n')}

**COMPREHENSIVE ANALYSIS REQUIRED:**

## **1. TOP CONCERNS ANALYSIS**
Identify the 5 most critical issues raised across all regions:
- Issue description and frequency
- Geographic distribution of concern
- Policy impact assessment

## **2. POSITIVE SENTIMENT ANALYSIS** 
Highlight the 5 most appreciated policy aspects:
- Specific positive feedback themes
- Regional variation in appreciation
- Success indicators

## **3. ACTIONABLE RECOMMENDATIONS**
Provide 7 concrete, implementable suggestions:
- Immediate actions (1-3 months)
- Medium-term improvements (3-12 months)  
- Long-term strategic changes (1-3 years)

## **4. GEOGRAPHICAL INSIGHTS**
Regional analysis showing:
- States with highest engagement
- Regional sentiment patterns
- Location-specific concerns

## **5. SENTIMENT TRENDS & PATTERNS**
- Overall public sentiment (${((sentimentBreakdown.positive || 0) / totalComments * 100).toFixed(1)}% positive)
- Key sentiment drivers
- Demographic insights

## **6. POLICY IMPLEMENTATION ROADMAP**
Strategic recommendations for policymakers including:
- Priority areas for immediate attention
- Resource allocation suggestions
- Communication strategy recommendations

**OUTPUT FORMAT:** Structure as a comprehensive policy brief with clear headings, bullet points, and actionable insights. Focus on data-driven recommendations that can improve policy effectiveness and public satisfaction.`;

      // Call Gemini AI API
      if (!process.env.GOOGLE_API_KEY) {
        return res.status(500).json({ message: "Google API key not configured" });
      }

      const response = await axios.post(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=${process.env.GOOGLE_API_KEY}`,
        {
          contents: [{
            parts: [{
              text: query
            }]
          }]
        },
        {
          headers: {
            'Content-Type': 'application/json'
          },
          timeout: 30000
        }
      );

      // Use marked library to convert markdown to clean, safe HTML for beautiful rendering
      const rawSummary = response.data.candidates?.[0]?.content?.parts?.[0]?.text || "AI analysis could not be generated at this time.";
      
      // Configure marked for clean HTML output
      marked.setOptions({
        breaks: true,
        gfm: true
      });
      
      // Convert markdown to HTML
      const htmlOutput = await marked(rawSummary);
      
      // Set up DOMPurify for server-side HTML sanitization
      const window = new JSDOM('').window;
      const DOMPurify = createDOMPurify(window as any);
      
      // Sanitize HTML while preserving formatting structure
      let cleanedSummary = DOMPurify.sanitize(htmlOutput, {
        ALLOWED_TAGS: ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'ul', 'ol', 'li', 'br', 'strong', 'em'],
        ALLOWED_ATTR: []
      });
      
      // BULLETPROOF asterisk elimination - catch every possible pattern
      cleanedSummary = cleanedSummary
        // Remove all standalone asterisks
        .replace(/\*/g, '')
        // Clean up any double spaces left behind
        .replace(/\s+/g, ' ')
        // Clean up any orphaned spaces at line starts
        .replace(/^\s+/gm, '')
        .trim();

      // Get vote statistics for the active policy
      const voteStats = await storage.getVoteStats(activePolicy.id);

      const insights = {
        summary: cleanedSummary,
        analysisDate: new Date().toISOString(),
        source: "Google Gemini AI",
        dataPoints: {
          totalComments: allComments.length,
          totalVotes: Object.values(voteStats).reduce((sum: number, count: number) => sum + count, 0),
          voteBreakdown: voteStats
        }
      };

      res.json(insights);
    } catch (error) {
      console.error('AI Insights Error:', error);
      
      // Fallback response if API fails
      const fallbackInsights = {
        summary: "AI analysis is temporarily unavailable. Based on the available data, this policy has received mixed feedback from citizens. Please review the individual comments and voting patterns for detailed insights.",
        analysisDate: new Date().toISOString(),
        dataPoints: {
          totalComments: 0,
          totalVotes: 0,
          voteBreakdown: { happy: 0, angry: 0, neutral: 0, suggestion: 0 }
        },
        source: "Gemini Fallback Analysis",
        error: "AI service unavailable"
      };
      
      res.json(fallbackInsights);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
