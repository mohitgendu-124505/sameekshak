import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { 
  Search, 
  FileText, 
  BarChart3, 
  Vote,
  Bell, 
  Settings,
  ChevronDown,
  ChevronRight,
  Home,
  MapPin,
  TrendingUp,
  MessageCircle,
  Lightbulb,
  PieChart,
  Cloud,
  Eye,
  Plus,
  Upload,
  Filter,
  Building,
  Wheat,
  Heart,
  Briefcase,
  Users
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@radix-ui/react-collapsible";

interface AppSidebarProps {
  isCollapsed: boolean;
  setIsCollapsed: (collapsed: boolean) => void;
}

export function AppSidebar({ isCollapsed, setIsCollapsed }: AppSidebarProps) {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [analyticsOpen, setAnalyticsOpen] = useState(true);
  const [policyOpen, setPolicyOpen] = useState(true);

  // Fetch data for sidebar counts
  const { data: policies } = useQuery({
    queryKey: ["/api/policies"],
  });

  const { data: currentPolicy } = useQuery({
    queryKey: ["/api/current-policy"],
  });

  const policyCategories = [
    { name: "Agriculture", icon: Wheat, count: 12, color: "bg-green-100 text-green-800" },
    { name: "Business", icon: Briefcase, count: 8, color: "bg-blue-100 text-blue-800" },
    { name: "Health", icon: Heart, count: 15, color: "bg-red-100 text-red-800" },
    { name: "Education", icon: Users, count: 10, color: "bg-purple-100 text-purple-800" },
  ];

  const sidebarWidth = isCollapsed ? "w-16" : "w-80";
  
  return (
    <motion.div
      initial={false}
      animate={{ width: isCollapsed ? 64 : 320 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className={cn(
        "fixed left-0 top-0 h-screen bg-card border-r border-border z-40 flex flex-col",
        sidebarWidth
      )}
    >
      {/* Logo & Toggle */}
      <div className="p-4 flex items-center justify-between border-b border-border">
        <AnimatePresence mode="wait">
          {!isCollapsed && (
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
              className="flex items-center space-x-3"
            >
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-sm">eS</span>
              </div>
              <span className="font-semibold text-lg text-foreground">e.Sameekshak</span>
            </motion.div>
          )}
        </AnimatePresence>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-1"
        >
          <motion.div
            animate={{ rotate: isCollapsed ? 0 : 180 }}
            transition={{ duration: 0.2 }}
          >
            <ChevronRight className="h-4 w-4" />
          </motion.div>
        </Button>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          {/* Search Bar */}
          <AnimatePresence>
            {!isCollapsed && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
              >
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search policies..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Dashboard Link */}
          <motion.div whileHover={{ x: 2 }} whileTap={{ scale: 0.98 }}>
            <Link href="/">
              <div className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-md cursor-pointer transition-colors",
                location === "/" 
                  ? "bg-primary text-primary-foreground" 
                  : "hover:bg-accent hover:text-accent-foreground"
              )}>
                <Home className="h-5 w-5" />
                {!isCollapsed && <span className="font-medium">Dashboard</span>}
              </div>
            </Link>
          </motion.div>

          {/* Policy Section */}
          <div className="space-y-2">
            <Collapsible open={policyOpen} onOpenChange={setPolicyOpen}>
              <CollapsibleTrigger className="flex items-center justify-between w-full px-3 py-2 text-sm font-medium hover:bg-accent rounded-md">
                <div className="flex items-center space-x-3">
                  <FileText className="h-5 w-5" />
                  {!isCollapsed && <span>Policies</span>}
                </div>
                {!isCollapsed && (
                  <motion.div
                    animate={{ rotate: policyOpen ? 90 : 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </motion.div>
                )}
              </CollapsibleTrigger>
              <CollapsibleContent>
                <AnimatePresence>
                  {!isCollapsed && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="ml-6 space-y-2"
                    >
                      <div className="flex items-center justify-between px-3 py-1 text-sm text-muted-foreground">
                        <span>Total Policies</span>
                        <Badge variant="secondary">{Array.isArray(policies) ? policies.length : 0}</Badge>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center justify-between px-3 py-1 text-xs text-muted-foreground">
                          <span>Categories</span>
                          <Filter className="h-3 w-3" />
                        </div>
                        
                        {policyCategories.map((category) => (
                          <motion.div
                            key={category.name}
                            whileHover={{ x: 4 }}
                            className="flex items-center justify-between px-3 py-2 hover:bg-accent rounded-md cursor-pointer"
                          >
                            <div className="flex items-center space-x-2">
                              <category.icon className="h-4 w-4" />
                              <span className="text-sm">{category.name}</span>
                            </div>
                            <Badge className={category.color} variant="secondary">
                              {category.count}
                            </Badge>
                          </motion.div>
                        ))}
                      </div>

                      <Separator />
                      
                      <div className="space-y-1">
                        <div className="px-3 py-1 text-xs text-muted-foreground">Policy Type</div>
                        <div className="px-3 py-2 hover:bg-accent rounded-md cursor-pointer text-sm">
                          <div className="flex items-center justify-between">
                            <span>Central Policies</span>
                            <Badge variant="secondary">24</Badge>
                          </div>
                        </div>
                        <div className="px-3 py-2 hover:bg-accent rounded-md cursor-pointer text-sm">
                          <div className="flex items-center justify-between">
                            <span>State Policies</span>
                            <Badge variant="secondary">21</Badge>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CollapsibleContent>
            </Collapsible>
          </div>

          {/* Analytics Section */}
          <div className="space-y-2">
            <Collapsible open={analyticsOpen} onOpenChange={setAnalyticsOpen}>
              <CollapsibleTrigger className="flex items-center justify-between w-full px-3 py-2 text-sm font-medium hover:bg-accent rounded-md">
                <div className="flex items-center space-x-3">
                  <BarChart3 className="h-5 w-5" />
                  {!isCollapsed && <span>Analytics</span>}
                </div>
                {!isCollapsed && (
                  <motion.div
                    animate={{ rotate: analyticsOpen ? 90 : 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </motion.div>
                )}
              </CollapsibleTrigger>
              <CollapsibleContent>
                <AnimatePresence>
                  {!isCollapsed && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="ml-6 space-y-1"
                    >
                      <Link href="/voting">
                        <motion.div whileHover={{ x: 4 }} className={cn(
                          "flex items-center space-x-2 px-3 py-2 rounded-md cursor-pointer text-sm transition-colors",
                          location === "/voting" 
                            ? "bg-primary text-primary-foreground" 
                            : "hover:bg-accent"
                        )}>
                          <Eye className="h-4 w-4" />
                          <span>Live Results</span>
                        </motion.div>
                      </Link>
                      
                      <motion.div whileHover={{ x: 4 }} className="flex items-center space-x-2 px-3 py-2 hover:bg-accent rounded-md cursor-pointer text-sm">
                        <PieChart className="h-4 w-4" />
                        <span>Vote Distribution</span>
                      </motion.div>
                      
                      <motion.div whileHover={{ x: 4 }} className="flex items-center space-x-2 px-3 py-2 hover:bg-accent rounded-md cursor-pointer text-sm">
                        <TrendingUp className="h-4 w-4" />
                        <span>Graphs</span>
                      </motion.div>
                      
                      <Link href="/summary">
                        <motion.div whileHover={{ x: 4 }} className={cn(
                          "flex items-center space-x-2 px-3 py-2 rounded-md cursor-pointer text-sm transition-colors",
                          location === "/summary" 
                            ? "bg-primary text-primary-foreground" 
                            : "hover:bg-accent"
                        )}>
                          <Lightbulb className="h-4 w-4" />
                          <span>AI Insights</span>
                        </motion.div>
                      </Link>
                      
                      <motion.div whileHover={{ x: 4 }} className="flex items-center space-x-2 px-3 py-2 hover:bg-accent rounded-md cursor-pointer text-sm">
                        <Cloud className="h-4 w-4" />
                        <span>Word Cloud</span>
                      </motion.div>
                      
                      <Link href="/emotion-map">
                        <motion.div whileHover={{ x: 4 }} className={cn(
                          "flex items-center space-x-2 px-3 py-2 rounded-md cursor-pointer text-sm transition-colors",
                          location === "/emotion-map" 
                            ? "bg-primary text-primary-foreground" 
                            : "hover:bg-accent"
                        )}>
                          <MapPin className="h-4 w-4" />
                          <span>Map Visualization</span>
                        </motion.div>
                      </Link>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CollapsibleContent>
            </Collapsible>
          </div>

          {/* Vote & Comment */}
          <motion.div whileHover={{ x: 2 }} whileTap={{ scale: 0.98 }}>
            <Link href="/voting">
              <div className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-md cursor-pointer transition-colors",
                location === "/voting" 
                  ? "bg-primary text-primary-foreground" 
                  : "hover:bg-accent hover:text-accent-foreground"
              )}>
                <Vote className="h-5 w-5" />
                {!isCollapsed && <span className="font-medium">Vote & Comment</span>}
              </div>
            </Link>
          </motion.div>

          {/* Notifications */}
          <motion.div whileHover={{ x: 2 }} whileTap={{ scale: 0.98 }}>
            <div className="flex items-center space-x-3 px-3 py-2 rounded-md cursor-pointer hover:bg-accent transition-colors">
              <Bell className="h-5 w-5" />
              {!isCollapsed && (
                <div className="flex items-center justify-between flex-1">
                  <span className="font-medium">Notifications</span>
                  <Badge className="bg-red-100 text-red-800">3</Badge>
                </div>
              )}
            </div>
          </motion.div>

          {/* Manage Policy */}
          <motion.div whileHover={{ x: 2 }} whileTap={{ scale: 0.98 }}>
            <Link href="/manage">
              <div className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-md cursor-pointer transition-colors",
                location === "/manage" 
                  ? "bg-primary text-primary-foreground" 
                  : "hover:bg-accent hover:text-accent-foreground"
              )}>
                <Settings className="h-5 w-5" />
                {!isCollapsed && (
                  <div className="flex-1">
                    <div className="font-medium">Manage Policy</div>
                    <div className="text-xs text-muted-foreground">Admin Only</div>
                  </div>
                )}
              </div>
            </Link>
          </motion.div>

          {!isCollapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="space-y-2"
            >
              <Separator />
              
              {/* Quick Actions */}
              <div className="space-y-2">
                <div className="px-3 py-1 text-xs font-medium text-muted-foreground">Quick Actions</div>
                
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button size="sm" className="w-full justify-start" variant="outline">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Policy
                  </Button>
                </motion.div>
                
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button size="sm" className="w-full justify-start" variant="outline">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload CSV
                  </Button>
                </motion.div>
              </div>
            </motion.div>
          )}
        </div>
      </ScrollArea>
    </motion.div>
  );
}